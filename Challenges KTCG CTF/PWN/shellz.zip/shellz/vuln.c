#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void setup(void){
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void banner(void){
    puts("=== Shellz on the Shore ===");
    puts("Give me your shellcode, I'll run it for you.");
}

void vuln(void){
    char buf[64];
    printf("Buffer is at: %p\n", (void*)buf);
    printf("shellcode> ");
    read(0, buf, 200);
}

int main(void){
    setup();
    banner();
    vuln();
    puts("done, bye!");
    return 0;
}
